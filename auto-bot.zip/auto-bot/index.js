import dotenv from 'dotenv';
dotenv.config();

import fs from 'fs';
import TelegramBot from 'node-telegram-bot-api';
import admin from 'firebase-admin';

const serviceAccount = JSON.parse(
  fs.readFileSync('./avtohunter-ua-firebase-adminsdk-fbsvc-f405a250c5.json', 'utf8')
);

// Перевірка змінних середовища
if (!process.env.BOT_TOKEN || !process.env.CHANNEL_ID) {
  console.error('❌ BOT_TOKEN або CHANNEL_ID не задано в .env');
  process.exit(1);
}

// Ініціалізація Firebase
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// Ініціалізація Telegram бота
const bot = new TelegramBot(process.env.BOT_TOKEN, { polling: true });
const channelId = process.env.CHANNEL_ID;
const users = {};

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  await bot.sendMessage(chatId, `Привіт, це *АвтоМайданчик UA*!  
Тут ти знайдеш авто на будь-який смак та бюджет 🚗  
Обери опцію нижче:`, {
    parse_mode: 'Markdown',
    reply_markup: {
      keyboard: [
        ['➕ Подати авто', '👤 Особистий кабінет'],
        ['🔍 Знайти авто']
      ],
      resize_keyboard: true
    }
  });
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;

  if (!users[chatId]) users[chatId] = {};

  switch (text) {
    case '➕ Подати авто':
      users[chatId] = { step: 'title', data: {} };
      await bot.sendMessage(chatId, 'Введи марку та модель авто (наприклад: BMW 320i):');
      break;

    case '👤 Особистий кабінет':
      const snapshot = await db.collection('cars').where('owner', '==', chatId).get();
      if (snapshot.empty) {
        await bot.sendMessage(chatId, 'У тебе ще немає оголошень.');
      } else {
        const listings = snapshot.docs.map(doc => {
          const car = doc.data();
          return `• *${car.title}* — ${car.price}$\n${car.description}`;
        }).join('\n\n');
        await bot.sendMessage(chatId, `Твої оголошення:\n\n${listings}`, { parse_mode: 'Markdown' });
      }
      break;

    case '🔍 Знайти авто':
      await bot.sendMessage(chatId, 'Оберіть цінову категорію:', {
        reply_markup: {
          keyboard: [['💰 До $2000', '💵 До $5000', '💎 Понад $6000']],
          resize_keyboard: true
        }
      });
      break;

    case '💰 До $2000':
    case '💵 До $5000':
    case '💎 Понад $6000': {
      let min = 0, max = 0;
      if (text.includes('2000')) {
        max = 2000;
      } else if (text.includes('5000')) {
        min = 2000; max = 5000;
      } else {
        min = 6000; max = 9999999;
      }

      const cars = await db.collection('cars')
        .where('price', '>=', min)
        .where('price', '<=', max)
        .get();

      if (cars.empty) {
        await bot.sendMessage(chatId, 'Авто не знайдено у цій категорії.');
      } else {
        for (let doc of cars.docs) {
          const car = doc.data();
          await bot.sendPhoto(chatId, car.photo, {
            caption: `*${car.title}*\nЦіна: ${car.price}$\nПробіг: ${car.mileage} км\nДвигун: ${car.engine}\nКоробка: ${car.gearbox}\n\n${car.description}`,
            parse_mode: 'Markdown'
          });
        }
      }
      break;
    }
  }

  const state = users[chatId];
  if (!state || !state.step) return;

  switch (state.step) {
    case 'title':
      state.data.title = text;
      state.step = 'description';
      await bot.sendMessage(chatId, 'Опиши авто:');
      break;

    case 'description':
      state.data.description = text;
      state.step = 'price';
      await bot.sendMessage(chatId, 'Вкажи ціну у $:');
      break;

    case 'price': {
      const price = parseInt(text);
      if (isNaN(price)) {
        await bot.sendMessage(chatId, 'Ціна має бути числом.');
        return;
      }
      state.data.price = price;
      state.step = 'mileage';
      await bot.sendMessage(chatId, 'Вкажи пробіг (у км):');
      break;
    }

    case 'mileage':
      state.data.mileage = text;
      state.step = 'engine';
      await bot.sendMessage(chatId, 'Вкажи обʼєм двигуна:');
      break;

    case 'engine':
      state.data.engine = text;
      state.step = 'gearbox';
      await bot.sendMessage(chatId, 'Яка коробка передач?');
      break;

    case 'gearbox':
      state.data.gearbox = text;
      state.step = 'photo';
      await bot.sendMessage(chatId, 'Надішли фото авто:');
      break;
  }
});

bot.on('photo', async (msg) => {
  const chatId = msg.chat.id;
  const state = users[chatId];
  if (!state || state.step !== 'photo') return;

  const photoId = msg.photo[msg.photo.length - 1].file_id;
  state.data.photo = photoId;
  state.data.owner = chatId;

  await db.collection('cars').add(state.data);

  await bot.sendMessage(chatId, '✅ Авто успішно опубліковано! Дякую!');
  await bot.sendPhoto(channelId, photoId, {
    caption: `*${state.data.title}*\nЦіна: ${state.data.price}$\nПробіг: ${state.data.mileage} км\nДвигун: ${state.data.engine}\nКоробка: ${state.data.gearbox}\n\n${state.data.description}`,
    parse_mode: 'Markdown'
  });

  delete users[chatId];
});
